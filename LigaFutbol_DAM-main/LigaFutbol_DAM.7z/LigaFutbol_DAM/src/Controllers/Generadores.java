package Controllers;

import Models.Entrenador;
import Models.Equipo;
import Models.Jugador;
import Utils.Repositorio;

import java.util.ArrayList;
import java.util.Arrays;

public class Generadores {

// Contendrá todos lo que sean generadores de Equipos, JUgadores, etc.



}
