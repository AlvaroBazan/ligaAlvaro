package Controllers;

public class MenuPrincipal {

    // El scanner para meter las instrucciones


}
