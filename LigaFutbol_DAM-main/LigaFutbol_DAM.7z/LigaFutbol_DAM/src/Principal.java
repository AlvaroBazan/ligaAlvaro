import Models.*;
import Utils.Aleatorio;
import Utils.Repositorio;
import java.text.SimpleDateFormat;
import java.util.*;

public class Principal {

	public static void main(String[] args) {

		// Estamos muy centrado en que sea futbol, pero... Y si quiero jugar al baloncesto, balonmano... XD (0.0)

		// Variables de configuracion básica
		int NUMERO_EQUIPOS = 20;
		int EDAD_JUGADORES = 10;

		// Siguiente paso son los CRUCES de EQUIPOS. Tengo una lista de equipos que quiero enfrentar entre ellos por orden.

		Equipo[] listaEquipos = crearEquipos(NUMERO_EQUIPOS, EDAD_JUGADORES);
		Arbitro[] arbitro = crearArbitro(NUMERO_EQUIPOS);

		//Equipo[][] equipos = (crucesDeEquipo(listaEquipos, listaEquipos, 0));
		//System.out.println(Arrays.stream(equipos[0]).toList());
		//System.out.println("\n\n\n");
		//System.out.println(Arrays.stream(equipos[1]).toList());

		Calendario calendario = CrearCalendario(NUMERO_EQUIPOS, listaEquipos, arbitro);
		//Jornada jornada = jornada(calendario, listaEquipos, NUMERO_EQUIPOS);
		Ranking(calendario, listaEquipos);

	}

	/*private static Jornada jornada(Calendario calendario, Equipo[] listaEquipos, int numeroEquipos) {


	}

*/
	private static Jugador[] crearJugadores(int numeroJugadores, int edad, Equipo equipo) {
		//Listado de Nombres, Apellidos, Posiciones para generador random
		String[] nombres = {"Juan", "Pepe", "Maria", "Rosa","Helena", "Migue", "Moises","Noemí", "Angélica", "Antonio", "Cristian", "Raul", "Alberto", "Sergio", "Belen"};

		String[] apellidos = {"García", "González", "Rodríguez", "Fernández", "López", "Martínez", "Sánchez", "Pérez", "Gómez", "Martin", "Jiménez", "Ruiz", "Hernández", "Diaz", "Moreno", "Muñoz", "Álvarez", "Romero", "Alonso", "Gutiérrez", "Navarro", "Torres", "Domínguez", "Vázquez", "Ramos", "Gil", "Ramírez", "Serrano", "Blanco", "Molina", "Morales", "Suarez", "Ortega", "Delgado", "Castro", "Ortiz", "Rubio", "Marín", "Sanz", "Núñez", "Iglesias", "Medina", "Garrido", "Cortes", "Castillo", "Santos", "Lozano", "Guerrero", "Cano", "Prieto", "Méndez", "Cruz", "Calvo", "Gallego", "Vidal", "León", "Márquez", "Herrera", "Peña", "Flores", "Cabrera", "Campos", "Vega", "Fuentes", "Carrasco", "Diez", "Caballero", "Reyes", "Nieto", "Aguilar", "Pascual", "Santana", "Herrero", "Lorenzo", "Montero", "Hidalgo", "Giménez", "Ibáñez", "Ferrer", "Duran", "Santiago", "Benítez", "Mora", "Vicente", "Vargas", "Arias", "Carmona", "Crespo", "Román", "Pastor", "Soto", "Sáez", "Velasco", "Moya", "Soler", "Parra", "Esteban", "Bravo", "Gallardo", "Rojas"};

		String[] listadoPosiciones = {"Portero", "Portero", "Defensa","Defensa","Defensa","Defensa","Defensa","Defensa","Defensa","Defensa",
				"Centro Campista","Centro Campista","Centro Campista","Centro Campista","Centro Campista","Centro Campista","Centro Campista","Centro Campista",
				"Delantero","Delantero","Delantero","Delantero"};

		ArrayList<String> posiciones = new ArrayList<>(Arrays.asList(listadoPosiciones));

		Integer[] listadoDorsales = {1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22};
		ArrayList<Integer> dorsales = new ArrayList<>(List.of(listadoDorsales));

		//Estructura de Array de Jugadores
		Jugador[] jugadores = new Jugador[numeroJugadores];

		for (int i=0; i<numeroJugadores; i++) {
			//Crear un Models.Jugador
			Jugador jug = new Jugador();
			//Nombre
			int numero = (int) Math.floor(Math.random()*nombres.length);
			String nombre = nombres[numero];
			//jug.setNombre(nombre);

			//Apellidos
			numero = (int) Math.floor(Math.random()*apellidos.length);
			String apellido1 = apellidos[numero];
			numero = (int) Math.floor(Math.random()*apellidos.length);
			String apellido2 = apellidos[numero];
			//jug.setApellidos(apellido1+" "+apellido2);

			//Posición
			String posicionFinal = posiciones.get(0);
			jug.setPosicion(posicionFinal);
			posiciones.remove(0);

			//Edad
			jug.setEdad(edad);

			//Dorsal

			int dorsalFinal = dorsales.get(0);
			jug.setDorsal(dorsalFinal);
			dorsales.remove(0);

			//Models.Equipo
			jug.setEquipo(equipo);

			jugadores[i]=jug;
		}

		return jugadores;
	}
	private static Entrenador crearEntrenador(Equipo equipo) {
		String[] nombres = Repositorio.nombres;
		String[] apellidos = Repositorio.apellidos;

		Entrenador entrenador = new Entrenador();

		//Nombre
		int numero = (int) Math.floor(Math.random()*nombres.length);
		String nombre = nombres[numero];
		//entrenador.setNombre(nombre);

		//Apellidos
		numero = (int) Math.floor(Math.random()*apellidos.length);
		String apellido1 = apellidos[numero];
		numero = (int) Math.floor(Math.random()*apellidos.length);
		String apellido2 = apellidos[numero];
		//entrenador.setApellidos(apellido1+" "+apellido2);

		//Models.Equipo
		entrenador.setEquipo(equipo);

		//Edad
		int edad = (int) Math.floor(Math.random()*47)+18;
		entrenador.setEdad(edad);
		//Licencia
		int licencia = (int) Math.floor(Math.random()*100000);
		entrenador.setNumeroLicencia(licencia);

		return entrenador;
	}
	private static Arbitro[] crearArbitro(int numeroEquipos){
		Arbitro[] arbitro = new Arbitro[numeroEquipos / 2];

		for (int i = 0; i < numeroEquipos / 2; i++) {
			Arbitro arbitroTemporal = new Arbitro();
			arbitro[i] = arbitroTemporal;
		}
		return arbitro;
	}

	private static Equipo[] crearEquipos(int numeroEquipos,int edad) {
		String[] nombreBarrios = Repositorio.nombreBarrios;
		String[] mascotas = Repositorio.mascotas;

		Equipo [] listaEquipos= new Equipo[numeroEquipos];

		ArrayList<String> barriosArraylist = new ArrayList<>(Arrays.asList(nombreBarrios));
		ArrayList<String> mascotasArraylist = new ArrayList<>(Arrays.asList(mascotas));

		for (int i=0; i<numeroEquipos; i++) {
			//Creamos Models.Equipo
			Equipo equipo = new Equipo();

			//Elegimos random un nombre y una mascota de las listas respectivas.
			int numero = (int) Math.floor(Math.random()*barriosArraylist.size());
			String barrio= barriosArraylist.get(numero);

			// Ahora deberíamos crear de nuevo el String[] nombreBarrios sin la posicion seleccionada anteriormente, para que en la próxima vuelta ya no esté
			barriosArraylist.remove(numero);

			numero = (int) Math.floor(Math.random()*mascotasArraylist.size());
			String mascota= mascotasArraylist.get(numero);

			mascotasArraylist.remove(numero);

			//Definimos el club en base al nombre del barrio
			equipo.setClub(barrio+" F.C.");


			//Las pegamos con un "de" en medio
			String nombre;
			if (barrio.startsWith("El ")) {
				barrio=barrio.substring(3);
				nombre = mascota + " del "+ barrio;
			}else {
				nombre = mascota + " de "+ barrio;
			}

			equipo.setNombre(nombre);
			//Continuamos con entrenador
			Entrenador entrenador = crearEntrenador(equipo);
			equipo.setEntrenador(entrenador);

			//Meter los jugadores
			//int numeroJugadores=(int) Math.floor(Math.random()*7)+15;

			Jugador[] jugadores = crearJugadores(22,edad,equipo);
			equipo.setJugadores(jugadores);

			//Meter el equipo en el array de equipos

			listaEquipos[i]=equipo;

		}
		return listaEquipos;

	}
	private static Partido JugarPartido(Equipo primerEquipo, Equipo segundoEquipo) {
		int golesEquipoUno = Aleatorio.generadorRandom();
		int golesEquipoDos = Aleatorio.generadorRandom();
		//	System.out.println(primerEquipo.getNombre()+ " " + golesEquipoUno + " - "+ golesEquipoDos + " " + segundoEquipo.getNombre());
		//	System.out.println(primerEquipo.toString());
		Partido partidos = new Partido();
		partidos.setEquipoLocal(primerEquipo);
		partidos.setEquipoVisitante(segundoEquipo);
		partidos.setGolEquipoLocal(golesEquipoUno);
		partidos.setGolEquipoVisitante(golesEquipoDos);

		//	System.out.println(partidos.toString());
		return partidos;
	}

	// Algoritmo que me va a ir cruzando los equipos en el modelo estandar de cruzes Primero-Ultimo y Doble vuelta.
	private static Equipo[][] crucesDeEquipo(Equipo[] listadoLocal, Equipo[] listadoVisitante, int numeroJornada){
		Equipo[] equiposL = new Equipo[listadoLocal.length];
		Equipo[] equiposV = new Equipo[listadoVisitante.length];

		ArrayList<Integer> arrayList = new ArrayList<>();
		for (int i = 0; i < equiposL.length; i++) {
			arrayList.add(numeroJornada);
			numeroJornada++;
			if (numeroJornada == 20) numeroJornada = 0;
		}
		for (int i = 0; i < listadoLocal.length; i++) {
			equiposL[i] = listadoLocal[arrayList.get(i)];
		}
		System.out.println(arrayList);
		arrayList.clear();

		//-------------------------------//

		for (int i = 0; i < equiposV.length; i++) {
			arrayList.add(numeroJornada);
			numeroJornada++;
			arrayList.sort(Comparator.reverseOrder());
			if (numeroJornada == 20) numeroJornada = 0;
		}
		System.out.println(arrayList);

		for (int i = 0; i < listadoVisitante.length; i++) {
			equiposV[i] = listadoVisitante[arrayList.get(i)];
		}

		Equipo[][] equipos = new Equipo[equiposL.length][equiposV.length];
		equipos[0] = equiposL;
		equipos[1] = equiposV;

		return equipos;
	}

	//La jornada establece cúantos partidos se juegan ese finde de semana


	// El calendario establece cúantos fines de semana se juega
	private static Calendario CrearCalendario(int numeroEquipos, Equipo[] listaEquipos, Arbitro[] arbitro) {
		Calendar calendar = new GregorianCalendar(2022, 0, 1);
		SimpleDateFormat sdf = new SimpleDateFormat("dd MMM yyyy HH:mm");

		Calendario calendario = new Calendario();
		//calendario.setJornada(jornada);
		Jornada[] jornada = new Jornada[numeroEquipos * 2 - 2];

		// Generador de Jornadas
		for (int i = 0; i < numeroEquipos * 2 - 2; i++) {

			//System.out.println("Jornada Número:"+ (i+1));
			Jornada jornada1 = new Jornada();

			jornada1.setNumeroJornada(i + 1);
			calendar.set(Calendar.HOUR_OF_DAY, 12);
			jornada1.setFecha(calendar.getTime());

			calendar.set(Calendar.HOUR_OF_DAY, 12);

			Partido[] partido = new Partido[numeroEquipos / 2];

			for (int j = 0; j < numeroEquipos / 2; j++) {


				if (j < (numeroEquipos / 2) / 2) {

					Partido partido1 = (JugarPartido(listaEquipos[j],listaEquipos[listaEquipos.length/2+j]));
					partido1.setDate(calendar.getTime());

					int numero = (int) Math.floor(Math.random()*arbitro.length); // Lo cojo de la lista de árbitros un árbitro aleatorio;
					Arbitro arbitro1 = arbitro[numero];							// se lo asigno a un árbitro temporal que hemos creado nuevo para ir machacándolo en cada paso de PARTIDO
					partido1.setArbitro(arbitro1);
					// se lo meto al array de los partidos que voy a sumar luego a la JORNADA

					partido[j] = partido1;

				} else {
					//	System.out.println("Partido: " + (j + 1) + " Domingo día -> " + sdf.format(calendar.getTime()));
					Partido partido1 = new Partido();
					partido1 = (JugarPartido(listaEquipos[j],listaEquipos[listaEquipos.length/2+j]));
					partido1.setDate(calendar.getTime());

					int numero = (int) Math.floor(Math.random()*arbitro.length);
					Arbitro arbitro1 = arbitro[numero];
					partido1.setArbitro(arbitro1);

					partido[j] = partido1;

				}
				calendar.add(Calendar.HOUR_OF_DAY,2);

				if (calendar.get(Calendar.HOUR_OF_DAY) > 20) {
					calendar.add(Calendar.HOUR, 14);
				}

				jornada1.setPartido(partido);

			}

			calendar.add(Calendar.DAY_OF_WEEK, 5);

			jornada[i] = jornada1;

			System.out.println("jornada que pasa 1"+jornada1);
		}
		calendario.setJornada(jornada);

		return calendario;
	}

	private static void Ranking(Calendario calendario, Equipo[] listaEquipos){

		Clasificacion[] clasificacion = new Clasificacion[listaEquipos.length];

		for (int p = 0; p < listaEquipos.length; p++) {
			Clasificacion clasificacion1 = new Clasificacion();
			clasificacion1.setEquipo(listaEquipos[p]);
			clasificacion[p] = clasificacion1;
		}

		for (int i = 0; i < calendario.getJornada().length; i++) {

			Jornada jornada = calendario.getJornada()[i];
			System.out.println(jornada);

			int equipoLocal = 0;
			int equipoVisitante = 1;

			for (int j = 0; j < jornada.getPartido().length; j++) {
				Partido partido = jornada.getPartido()[j];

				clasificacion[equipoLocal].setPartidosJugados(clasificacion[equipoLocal].getPartidosJugados()+1);
				clasificacion[equipoLocal].setGolesFavor(clasificacion[equipoLocal].getGolesFavor()+partido.getGolEquipoLocal());
				clasificacion[equipoLocal].setGolesContra(clasificacion[equipoLocal].getGolesContra()+partido.getGolEquipoVisitante());

				clasificacion[equipoVisitante].setPartidosJugados(clasificacion[equipoVisitante].getPartidosJugados()+1);
				clasificacion[equipoVisitante].setGolesFavor(clasificacion[equipoVisitante].getGolesFavor()+partido.getGolEquipoVisitante());
				clasificacion[equipoVisitante].setGolesContra(clasificacion[equipoVisitante].getGolesContra()+partido.getGolEquipoLocal());

				int golesLocales = partido.getGolEquipoLocal();
				int golesVisitantes = partido.getGolEquipoVisitante();

				if (golesLocales > golesVisitantes){
					clasificacion[equipoLocal].setPuntosTotales((clasificacion[equipoLocal].getPuntosTotales()+3));
					clasificacion[equipoLocal].setPartidosGanados(clasificacion[equipoLocal].getPartidosGanados()+1);
					clasificacion[equipoVisitante].setPartidosPerdidos(clasificacion[equipoVisitante].getPartidosPerdidos()+1);
				} else if (golesLocales < golesVisitantes){
					clasificacion[(equipoVisitante)].setPuntosTotales((clasificacion[equipoVisitante].getPuntosTotales()+3));
					clasificacion[equipoVisitante].setPartidosGanados(clasificacion[equipoVisitante].getPartidosGanados()+1);
					clasificacion[equipoLocal].setPartidosPerdidos(clasificacion[equipoLocal].getPartidosPerdidos()+1);
				} else if (golesLocales == golesVisitantes){
					clasificacion[(equipoVisitante)].setPuntosTotales((clasificacion[equipoVisitante].getPuntosTotales()+1));
					clasificacion[equipoLocal].setPuntosTotales((clasificacion[equipoLocal].getPuntosTotales()+1));
					clasificacion[equipoLocal].setPartidosEmpatados(clasificacion[equipoLocal].getPartidosEmpatados()+1);
					clasificacion[equipoVisitante].setPartidosEmpatados(clasificacion[equipoVisitante].getPartidosEmpatados()+1);
				}

				equipoLocal+=2;
				equipoVisitante+=2;

			}

		}

		ArrayList<Clasificacion> listaEquiposOrdenar = new ArrayList<Clasificacion>();


		// le doy una lista de puntos totales y la ordeno. Lo que recibo luego lo meto en una nueva clasificacion y ese es el orden final de los EQUIPOS dentro de la CLASIFICACION.
		for (int i = 0; i < clasificacion.length; i++) {
			listaEquiposOrdenar.add(clasificacion[i]);
		}

		Collections.sort(listaEquiposOrdenar, new Comparator<Clasificacion>() {
			@Override
			public int compare(Clasificacion p1, Clasificacion p2) {
				return new Integer(p2.getPuntosTotales()).compareTo(new Integer(p1.getPuntosTotales()));
			}
		});

		for (int i = 0; i < ordenarClasificacion(listaEquiposOrdenar).length; i++) {
			System.out.println("Clasificación final: "+		ordenarClasificacion(listaEquiposOrdenar)[i]);
		}

	}

	private static Clasificacion[] ordenarClasificacion(ArrayList<Clasificacion>listaEquiposOrdenar ){

		Clasificacion[] clasificacions = new Clasificacion[listaEquiposOrdenar.size()];

		for (int i = 0; i < listaEquiposOrdenar.size(); i++) {
			Clasificacion clasificacion1 = new Clasificacion();

			clasificacion1.setEquipo(listaEquiposOrdenar.get(i).getEquipo());
			clasificacion1.setPuntosTotales(listaEquiposOrdenar.get(i).getPuntosTotales());
			clasificacion1.setPartidosJugados(listaEquiposOrdenar.get(i).getPartidosJugados());
			clasificacion1.setPartidosGanados(listaEquiposOrdenar.get(i).getPartidosGanados());
			clasificacion1.setPartidosEmpatados(listaEquiposOrdenar.get(i).getPartidosEmpatados());
			clasificacion1.setPartidosPerdidos(listaEquiposOrdenar.get(i).getPartidosPerdidos());
			clasificacion1.setGolesFavor(listaEquiposOrdenar.get(i).getGolesFavor());
			clasificacion1.setGolesContra(listaEquiposOrdenar.get(i).getGolesContra());


			clasificacions[i] = clasificacion1;
		}

		return clasificacions;
	}


}