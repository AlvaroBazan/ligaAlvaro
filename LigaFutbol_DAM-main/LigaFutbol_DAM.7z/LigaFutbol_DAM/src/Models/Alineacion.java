package Models;

public class Alineacion {

    int[] formacion;            //  formacion clasica -> {4,4,2}  formacion en aguila {3,5,2}
    Jugador titulares;
    Jugador suplentes;
    Entrenador entrenador;

    /**
     * Titulares, Suplentes, Formacion (4-4-2, 3-5-2), Models.Entrenador, Cambios,
     *
     * formacion = 3,5,2;
     * Selecciones automaticamente 3 defensas, 5 centrocampistas, 2 delanteros.
     *
     */
/*
    Integer[] formacion;

    formacion[3] = {3,5,2};

    Models.Jugador[] jugadores;

    jugadores[jugador[1],]
*/

}