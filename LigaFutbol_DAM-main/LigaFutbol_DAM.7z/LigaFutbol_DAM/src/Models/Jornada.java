package Models;

import java.util.Arrays;
import java.util.Date;

public class Jornada extends Calendario {

    private int numeroJornada;
    private Date Fecha;
    Partido[] partido;

    public int getNumeroJornada() {
        return numeroJornada;
    }

    public void setNumeroJornada(int numeroJornada) {
        this.numeroJornada = numeroJornada;
    }

    public Date getFecha() {
        return Fecha;
    }

    public void setFecha(Date fecha) {
        Fecha = fecha;
    }

    public Partido[] getPartido() {
        return partido;
    }

    public void setPartido(Partido[] partido) {
        this.partido = partido;
    }

    @Override
    public String toString() {
        return  "\nNumeroJornada=" + numeroJornada +
                " Fecha: " + Fecha+"\n"+
                " Partido = " + Arrays.toString(partido);
    }



/**
     * La clase jornada se refiere a una sola jornada del Models.Calendario de la liga. En esta jornada habrá una lista de partidos determinados en base al calendario original.
     * De tal modo en la clase jornada podremos:
     * • Crear Partidos
     * • Asignar árbitros a partidos (ver más abajo)
     * • Asignar horarios a partidos.
     * • Modificar datos de partidos.
     * • Etc.
     *
     * OPCIONAL:
     * Considera la situación en que el número de árbitros pueda limitar
     * los horarios de los partidos. Por ejemplo, si tus partidos son en
     * sábados y domingos en horarios de mañana y tarde pero solo tienes
     * 1 arbitro por cada 8 equipos, entonces tendrás que calcular
     * (de manera automática), que cada árbitro tendrá que pitar dos
     * partidos cada día, uno en cada horario.
     */

    

}
