package Models;

import Models.Jornada;

import java.util.Arrays;

public class Calendario {

    // TIENE QUE GENERA LAS JORNADAS

    // Calendario de 1 vuelta, Torneo, Que se pueda  elegir cosas.

    Jornada[] jornada;

    public Calendario() {
    }

    public Jornada[] getJornada() {
        return jornada;
    }

    public void setJornada(Jornada[] jornada) {
        this.jornada = jornada;
    }

    @Override
    public String toString() {
        return "Calendario" +
                " Jornada=" + Arrays.toString(jornada);
    }


    //Define los fines de semana del año y el número de partidos que hay.
    // Va a realizar una matriz dimension 2 para los cruces. Cogiendo el primer equipo contra el ultimo para la primera vuelta y viceversa para la segunda vuelta.



    /**
     * La clase calendario es la interfaz que comunica a la clase liga con las diferentes jornadas. Estudiad su viabilidad y necesidad.
     * Si veis que no es necesaria, eliminadla (siempre justificando por qué).
     * En esta clase podremos ir ajustando las fechas de las diferentes jornadas, tendremos un listado de las diferentes jornadas y las operaciones necesarias para trabajar con ellas.
     * La utilidad inicial de clase es dejar el código más claro en la clase Models.Liga que “hace uso” de dicha clase (mirad esto en teoría).
     */
}
