package Models;

import Models.Persona;

public class Arbitro extends Persona {
	int licencia;

	public int getLicencia() {
		return licencia;
	}

	public void setLicencia(int licencia) {
		this.licencia = licencia;
	}

	public Arbitro() {
		int licencia = (int) Math.floor(Math.random()*100000);
		this.licencia = licencia;
		//int edad = (int) Math.floor(Math.random()*33)+18;
		super.setEdad(33,18);
	}

	@Override
	public String toString() {
		return "Arbitro: " + this.getNombre() +" " + getApellidos()+"\n";
	}

}