package Models;

public class Liga {
	
	private String nombre;
	private Calendario calendario; // Crea los fines de semana que se van a jugar. Necesita el número de equipos de liga
	private Clasificacion clasificacion; // Retorna el valor de en base a la jornada.
	private Equipo[] equipos; // listado de equipos de la liga
	private Arbitro[] arbitros; // listado de arbitros de la liga

}
