package Models;
import Utils.Repositorio;

public abstract class Persona {
	private String nombre;
	private String apellidos;
	private int edad;

	public Persona() {
		String[] nombres = Repositorio.nombres;
		int numero = (int) Math.floor(Math.random()*nombres.length);
		String nombre = nombres[numero];
		this.nombre = nombre;

		String[] listaApellidos = Repositorio.apellidos;
		numero = (int) Math.floor(Math.random()*listaApellidos.length);
		String apellido1 = listaApellidos[numero];
		numero = (int) Math.floor(Math.random()*listaApellidos.length);
		String apellido2 = listaApellidos[numero];
		this.apellidos = apellido1 + " " +apellido2;
	}

	public String getNombre() {
		return nombre;
	}
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	public String getApellidos() {
		return apellidos;
	}
	public void setApellidos(String apellidos) {
		this.apellidos = apellidos;
	}
	public int getEdad() {
		return edad;
	}

	public void setEdad(int edadMin, int edadMax){
		int edad2 = (int) Math.floor(Math.random()*edadMax)+edadMin;
		this.edad = edad2;
	}
/*	public void setEdad(int edad) {
		this.edad = edad;
	}*/
	
	@Override
	public String toString() {
		return "Nombre: "+ this.nombre+" "+this.apellidos+ " Edad: "+this.edad;
	}

}