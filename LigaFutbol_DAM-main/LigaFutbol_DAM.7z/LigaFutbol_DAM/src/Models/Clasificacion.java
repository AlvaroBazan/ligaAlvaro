package Models;

public class Clasificacion {

    /**
     * En esta clase lo que haremos será crear una clasificación con un criterio (que os dejo que propongáis) que nos indique
     * (basándonos en los diferentes partidos de cada equipo) el ranking de los diferentes equipos en la liga.
     * Estudia los atributos necesarios, la manera de calcularlos y los métodos útiles para la realización de esta clase.
     */

    public Equipo equipo;
    public int puntosTotales;
    public int partidosJugados;
    public int partidosGanados;
    public int partidosEmpatados;
    public int partidosPerdidos;
    public int golesFavor;
    public int golesContra;


    public Equipo getEquipo() {
        return equipo;
    }

    public void setEquipo(Equipo equipo) {
        this.equipo = equipo;
    }

    public int getPuntosTotales() {
        return puntosTotales;
    }

    public void setPuntosTotales(int puntosTotales) {
        this.puntosTotales = puntosTotales;
    }

    public int getPartidosJugados() {
        return partidosJugados;
    }

    public void setPartidosJugados(int partidosJugados) {
        this.partidosJugados = partidosJugados;
    }

    public int getPartidosGanados() {
        return partidosGanados;
    }

    public void setPartidosGanados(int partidosGanados) {
        this.partidosGanados = partidosGanados;
    }

    public int getPartidosEmpatados() {
        return partidosEmpatados;
    }

    public void setPartidosEmpatados(int partidosEmpatados) {
        this.partidosEmpatados = partidosEmpatados;
    }

    public int getPartidosPerdidos() {
        return partidosPerdidos;
    }

    public void setPartidosPerdidos(int partidosPerdidos) {
        this.partidosPerdidos = partidosPerdidos;
    }

    public int getGolesFavor() {
        return golesFavor;
    }

    public void setGolesFavor(int golesFavor) {
        this.golesFavor = golesFavor;
    }

    public int getGolesContra() {
        return golesContra;
    }

    public void setGolesContra(int golesContra) {
        this.golesContra = golesContra;
    }

    @Override
    public String toString() {
        return  "\nEquipo: " + equipo.getNombre().toString()+
                "\nPuntos Totales: " + puntosTotales +
                "\nPartidos Jugados: " + partidosJugados +
                "\nPartidos Ganados: " + partidosGanados +
                "\nPartidos Empatados: " + partidosEmpatados +
                "\npartidosPerdidos: " + partidosPerdidos +
                "\ngolesFavor: " + golesFavor +
                "\ngolesContra: " + golesContra+"\n";
    }
}